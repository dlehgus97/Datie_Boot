package org.zerock.datie_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatieBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatieBootApplication.class, args);
	}

}
